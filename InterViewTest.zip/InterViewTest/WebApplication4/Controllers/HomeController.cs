﻿using Microsoft.Ajax.Utilities;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using WebApplication4.Models;

namespace WebApplication4.Controllers
{
    public class HomeController : Controller
    {
        static IList<Customer> cust = new List<Customer>
        {
                    new Customer(){ customerID = 001,
                                    Name = "A.Jain",
                                    Email = "a.jain@emailtest.com",
                                    PhoneNumber = 9800012345},
                    new Customer()
                    {
                        customerID = 002,
                                    Name = "D.Pal",
                                    Email = "dpal014@emailtest.com",
                                    PhoneNumber = 9800012345
                    },
                    new Customer()
                    {
                     customerID = 003,
                                    Name = "S.Mitra",
                                    Email = "smitra_123@testyahoo.com",
                                    PhoneNumber = 9800012345
                    },
                    new Customer()
                    {
                        customerID = 004,
                                    Name = "P.Mukherjee",
                                    Email = "pm321@gmailtest.com",
                                    PhoneNumber = 9800012345
                    }
        };


        public ActionResult Index()
        {
            return View(cust);
        }
        public ActionResult Edit(int id)
        {
            var customer = cust.Where(c => c.customerID == id).FirstOrDefault();
            return View(customer);
        }
        [HttpPost]
        public ActionResult Edit(Customer customer)
        {
            var cus = cust.Where(c => c.customerID == customer.customerID).FirstOrDefault();
            cust.Remove(cus);
            cust.Add(customer);
            return RedirectToAction("Index");

        }

        [HttpPost]
        public ActionResult Add(Customer customer)
        {
            cust.Add(customer);
            return RedirectToAction("Index");

        }

        public async Task<ActionResult>  GetImage()
        {
            return View();
        }
    }
}