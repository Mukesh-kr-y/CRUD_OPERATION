﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication4.Models
{
    public class GetImage
    {
        

        public int newsid { get; set; }

        public string title { get; set; }
        public string Path { get; set; }

    }
}